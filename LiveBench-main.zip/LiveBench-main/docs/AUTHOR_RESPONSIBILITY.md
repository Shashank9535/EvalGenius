# Author Responsibility

We, the authors, bear all responsibility in case of violation of rights. The license of our repository is the Apache License 2.0. For more information, see the full [license](https://github.com/LiveBench/LiveBench/blob/main/LICENSE).