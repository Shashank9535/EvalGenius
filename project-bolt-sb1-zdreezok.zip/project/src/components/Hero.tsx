import React from 'react';
import { BarChart3, Brain, Database, Shield, Zap } from 'lucide-react';

const Hero = () => {
  return (
    <div className="pt-24 pb-16 bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-7 lg:text-left">
            <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full bg-blue-100 dark:bg-blue-900/30 mb-8">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-blue-500"></span>
              </span>
              <span className="text-sm font-medium text-blue-800 dark:text-blue-200">Live Benchmarking</span>
            </div>
            <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 dark:text-white sm:text-5xl md:text-6xl">
              <span className="block">Real-time LLM</span>
              <span className="block text-blue-600 dark:text-blue-400">Performance Insights</span>
            </h1>
            <p className="mt-6 text-base text-gray-600 dark:text-gray-300 sm:text-xl lg:text-lg xl:text-xl leading-relaxed">
              Track, compare, and analyze Language Models in real-time. Get comprehensive benchmarks across multiple dimensions, from accuracy to inference speed.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row sm:justify-center lg:justify-start gap-4">
              <button className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 transition-colors duration-150">
                Start Benchmarking
                <BarChart3 className="ml-2 h-5 w-5" />
              </button>
              <button className="inline-flex items-center px-6 py-3 border-2 border-blue-600 dark:border-blue-400 text-base font-medium rounded-lg text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors duration-150">
                View Documentation
              </button>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-6">
              {[
                { label: 'Models Tracked', value: '50+' },
                { label: 'Daily Evaluations', value: '1M+' },
                { label: 'Benchmark Tasks', value: '200+' }
              ].map((stat) => (
                <div key={stat.label} className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-lg p-4">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{stat.value}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-5 lg:flex lg:items-center">
            <div className="relative mx-auto w-full rounded-xl shadow-2xl lg:max-w-md overflow-hidden bg-gradient-to-br from-blue-600 to-indigo-600 dark:from-blue-500 dark:to-indigo-500 p-1">
              <div className="relative block w-full bg-white dark:bg-gray-900 rounded-lg overflow-hidden">
                <img
                  className="w-full"
                  src="https://images.unsplash.com/photo-1676299081847-824916de030a?auto=format&fit=crop&q=80&w=800"
                  alt="AI Visualization"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-6">
                  <div className="text-white">
                    <h3 className="font-semibold text-lg">Real-time Metrics</h3>
                    <p className="text-sm text-gray-200">Continuously updated benchmarks</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;