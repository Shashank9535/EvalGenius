import React from 'react';
import { BarChart3, Brain, Database, Shield, Zap, Target, Cpu, Clock, AlertTriangle } from 'lucide-react';

const features = [
  {
    name: 'Real-time Analysis',
    description: 'Get instant performance metrics and analysis for your language models with continuous updates.',
    icon: BarChart3,
    color: 'from-blue-400 to-blue-600',
  },
  {
    name: 'Contamination Detection',
    description: 'Advanced algorithms to detect and prevent test set contamination, ensuring reliable benchmarks.',
    icon: Shield,
    color: 'from-indigo-400 to-indigo-600',
  },
  {
    name: 'Multi-dimensional Evaluation',
    description: 'Comprehensive assessment across accuracy, bias, efficiency, and robustness metrics.',
    icon: Target,
    color: 'from-purple-400 to-purple-600',
  },
  {
    name: 'Inference Speed',
    description: 'Track and optimize model performance with detailed latency and throughput metrics.',
    icon: Zap,
    color: 'from-orange-400 to-orange-600',
  },
  {
    name: 'Resource Monitoring',
    description: 'Monitor CPU, GPU, and memory usage during model evaluation.',
    icon: Cpu,
    color: 'from-green-400 to-green-600',
  },
  {
    name: 'Failure Analysis',
    description: 'Detailed analysis of model failures and edge cases.',
    icon: AlertTriangle,
    color: 'from-red-400 to-red-600',
  },
];

const Features = () => {
  return (
    <div id="features" className="py-24 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl">
            Advanced LLM Evaluation Platform
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-gray-600 dark:text-gray-300 mx-auto">
            Comprehensive tools and metrics for thorough model assessment
          </p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-12 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => (
              <div
                key={feature.name}
                className="relative group"
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r rounded-lg blur opacity-30 group-hover:opacity-100 transition duration-200"></div>
                <div className="relative bg-white dark:bg-gray-900 rounded-lg p-6">
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6`}>
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">
                    {feature.name}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-20">
          <div className="bg-white dark:bg-gray-900 rounded-xl shadow-xl overflow-hidden">
            <div className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
                Supported Evaluation Tasks
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[
                  'Text Generation',
                  'Question Answering',
                  'Summarization',
                  'Translation',
                  'Code Generation',
                  'Classification',
                  'Named Entity Recognition',
                  'Sentiment Analysis',
                  'Toxicity Detection'
                ].map((task) => (
                  <div key={task} className="flex items-center space-x-3 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <Brain className="h-5 w-5 text-blue-500" />
                    <span className="text-gray-700 dark:text-gray-300">{task}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Features;