import React, { useState } from 'react';
import { ArrowUpRight, ArrowDownRight, BarChart3, Zap, Brain, Target, Clock, Cpu, AlertTriangle, Shield } from 'lucide-react';

const models = [
  { 
    name: 'GPT-4',
    accuracy: 98.5,
    bias: 0.02,
    efficiency: 95.8,
    trend: 'up',
    change: '+0.3%',
    latency: '120ms',
    throughput: '850 req/s',
    lastUpdate: '2 min ago',
    status: 'active',
    contamination: 'clean',
    gpu_util: '85%',
    memory: '16GB',
    failures: '0.5%'
  },
  { 
    name: 'Claude 2',
    accuracy: 97.2,
    bias: 0.03,
    efficiency: 94.2,
    trend: 'down',
    change: '-0.1%',
    latency: '145ms',
    throughput: '720 req/s',
    lastUpdate: '1 min ago',
    status: 'active',
    contamination: 'clean',
    gpu_util: '78%',
    memory: '14GB',
    failures: '0.8%'
  },
  { 
    name: 'PaLM 2',
    accuracy: 96.8,
    bias: 0.04,
    efficiency: 93.5,
    trend: 'up',
    change: '+0.5%',
    latency: '98ms',
    throughput: '920 req/s',
    lastUpdate: '5 min ago',
    status: 'active',
    contamination: 'warning',
    gpu_util: '92%',
    memory: '18GB',
    failures: '1.2%'
  },
  { 
    name: 'LLaMA 2',
    accuracy: 95.4,
    bias: 0.05,
    efficiency: 92.1,
    trend: 'up',
    change: '+0.8%',
    latency: '110ms',
    throughput: '880 req/s',
    lastUpdate: '3 min ago',
    status: 'active',
    contamination: 'clean',
    gpu_util: '88%',
    memory: '12GB',
    failures: '0.9%'
  },
  { 
    name: 'Anthropic Claude',
    accuracy: 94.9,
    bias: 0.04,
    efficiency: 91.8,
    trend: 'down',
    change: '-0.2%',
    latency: '135ms',
    throughput: '750 req/s',
    lastUpdate: '4 min ago',
    status: 'active',
    contamination: 'clean',
    gpu_util: '82%',
    memory: '15GB',
    failures: '1.1%'
  },
];

const metrics = [
  { name: 'Accuracy', icon: Target },
  { name: 'Efficiency', icon: Zap },
  { name: 'Latency', icon: Clock },
  { name: 'Throughput', icon: Cpu },
  { name: 'Bias', icon: Brain },
  { name: 'Contamination', icon: Shield },
  { name: 'Failures', icon: AlertTriangle },
];

const Leaderboard = () => {
  const [selectedMetric, setSelectedMetric] = useState('Accuracy');
  const [timeRange, setTimeRange] = useState('24h');

  return (
    <div id="leaderboard" className="py-16 bg-white dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl">
                Live Performance Rankings
              </h2>
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-100 dark:bg-green-900/30">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="text-xs font-medium text-green-800 dark:text-green-200">LIVE</span>
              </div>
            </div>
            <p className="mt-4 text-xl text-gray-600 dark:text-gray-300">
              Real-time benchmarks across multiple dimensions
            </p>
          </div>
          <div className="mt-6 md:mt-0 flex flex-col gap-4">
            <div className="inline-flex flex-wrap gap-2 rounded-lg p-1 bg-gray-100 dark:bg-gray-800">
              {['1h', '24h', '7d', '30d'].map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-3 py-1 text-sm font-medium rounded-md ${
                    timeRange === range
                      ? 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-400 shadow-sm'
                      : 'text-gray-600 dark:text-gray-400'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
            <div className="inline-flex flex-wrap gap-2 rounded-lg p-1 bg-gray-100 dark:bg-gray-800">
              {metrics.map((metric) => {
                const Icon = metric.icon;
                return (
                  <button
                    key={metric.name}
                    onClick={() => setSelectedMetric(metric.name)}
                    className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                      selectedMetric === metric.name
                        ? 'bg-white dark:bg-gray-700 text-blue-600 dark:text-blue-400 shadow-sm'
                        : 'text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'
                    }`}
                  >
                    <Icon className="h-4 w-4 mr-2" />
                    {metric.name}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Active Models</h3>
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">5</span>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <Cpu className="h-4 w-4 mr-2" />
              All systems operational
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Avg Response Time</h3>
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">121.6ms</span>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <Clock className="h-4 w-4 mr-2" />
              Last minute average
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Total Requests</h3>
              <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">824K</span>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <BarChart3 className="h-4 w-4 mr-2" />
              Last 24 hours
            </div>
          </div>
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Contamination Alerts</h3>
              <span className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">1</span>
            </div>
            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
              <Shield className="h-4 w-4 mr-2" />
              1 model flagged
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 shadow-xl rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
              <thead>
                <tr className="bg-gray-50 dark:bg-gray-900">
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Rank
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Model
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Score
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    GPU Util
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Memory
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Change
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Last Update
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                {models.map((model, idx) => (
                  <tr
                    key={model.name}
                    className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors duration-150"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800">
                        <span className="text-sm font-medium text-gray-900 dark:text-white">
                          {idx + 1}
                        </span>
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="text-sm font-medium text-gray-900 dark:text-white">
                          {model.name}
                          {model.contamination === 'warning' && (
                            <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-800">
                              <Shield className="h-3 w-3 mr-1" />
                              Contamination Risk
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 dark:text-white">
                        {selectedMetric === 'Accuracy' && `${model.accuracy}%`}
                        {selectedMetric === 'Efficiency' && `${model.efficiency}%`}
                        {selectedMetric === 'Latency' && model.latency}
                        {selectedMetric === 'Throughput' && model.throughput}
                        {selectedMetric === 'Bias' && model.bias.toFixed(2)}
                        {selectedMetric === 'Contamination' && model.contamination}
                        {selectedMetric === 'Failures' && model.failures}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        {model.gpu_util}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        {model.memory}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex text-sm ${
                        model.trend === 'up'
                          ? 'text-green-600 dark:text-green-400'
                          : 'text-red-600 dark:text-red-400'
                      }`}>
                        {model.change}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-600 dark:text-gray-300">
                        {model.lastUpdate}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200">
                        <span className="relative flex h-2 w-2 mr-1">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                        </span>
                        Active
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;